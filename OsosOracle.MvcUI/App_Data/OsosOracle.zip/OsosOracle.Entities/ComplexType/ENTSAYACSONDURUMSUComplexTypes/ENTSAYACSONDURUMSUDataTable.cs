using System.Collections.Generic;
using OsosOracle.Framework.DataAccess;
namespace OsosOracle.Entities.ComplexType.ENTSAYACSONDURUMSUComplexTypes
{
	public class ENTSAYACSONDURUMSUDataTable : DataTable
	{
		public List<ENTSAYACSONDURUMSUDetay> ENTSAYACSONDURUMSUDetayList { get; set; }
	}
}
using System.Collections.Generic;
using OsosOracle.Entities.Concrete;

namespace OsosOracle.DataLayer.Concrete.EntityFramework.Entity
 {
    public sealed class ENTSAYACSONDURUMSUEf : ENTSAYACSONDURUMSU
    {


public  CSTDURUMEf CSTDURUMDURUMEf { get; set; }
public  ENTSAYACEf ENTSAYACKAYITNOEf { get; set; }
}
}

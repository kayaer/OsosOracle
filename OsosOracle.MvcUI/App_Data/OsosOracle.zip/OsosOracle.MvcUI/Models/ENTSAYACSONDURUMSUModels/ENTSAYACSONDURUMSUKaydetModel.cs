
using OsosOracle.Entities.Concrete;
namespace OsosOracle.MvcUI.Models.ENTSAYACSONDURUMSUModels
{
	public class ENTSAYACSONDURUMSUKaydetModel
	{
		public ENTSAYACSONDURUMSU ENTSAYACSONDURUMSU { get; set; }
	}
}


using OsosOracle.Entities.ComplexType.ENTSAYACSONDURUMSUComplexTypes;
namespace OsosOracle.MvcUI.Models.ENTSAYACSONDURUMSUModels
{
	public class ENTSAYACSONDURUMSUDetayModel
	{
		public ENTSAYACSONDURUMSUDetay ENTSAYACSONDURUMSUDetay { get; set; }
	}
}

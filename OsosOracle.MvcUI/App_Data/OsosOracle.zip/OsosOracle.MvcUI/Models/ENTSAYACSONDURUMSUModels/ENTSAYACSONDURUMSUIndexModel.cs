
using OsosOracle.Entities.ComplexType.ENTSAYACSONDURUMSUComplexTypes;
namespace OsosOracle.MvcUI.Models.ENTSAYACSONDURUMSUModels
{
	public class ENTSAYACSONDURUMSUIndexModel
	{
		public ENTSAYACSONDURUMSUAra ENTSAYACSONDURUMSUAra { get; set; }
	}
}
